#!/bin/bash
read val
for((i=1; i <= val; i++));
do
  echo "hello world"
done
exit 0